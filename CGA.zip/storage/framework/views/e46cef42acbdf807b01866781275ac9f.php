<?php $__env->startSection('title', 'A Propos'); ?>

<?php $__env->startSection(section: 'content'); ?>


    <!-- Header Start -->
    <div class="jumbotron jumbotron-fluid page-header position-relative overlay-bottom" style="margin-bottom: 100px;">
        <div class="container text-center py-5">
            <h1 class="text-white display-1">A Propos</h1>
            <div class="d-inline-flex text-white mb-5">
                <p class="m-0 text-uppercase"><a class="text-white" href="">Acceuil</a></p>
                <i class="fa fa-angle-double-right pt-1 px-3"></i>
                <p class="m-0 text-uppercase">A Propos</p>
         </div>
        </div>
    </div>
    <!-- Header End -->


    <!-- About Start -->
    <div class="container-fluid py-5">
        <div class="container py-5">
            <div class="row">
                <div class="col-lg-5 mb-5 mb-lg-0" style="min-height: 100px;">
                    <div class="position-relative h-100">
                        <img class="position-absolute w-100 h-100" src="img/about-10.png" style="object-fit: cover;">
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="section-title position-relative mb-4">
                        <h6 class="d-inline-block position-relative text-secondary text-uppercase pb-2">A Propos de Nous</h6>
                        <h1 class="display-4"> CGA 1ère EDITION </h1>
                    </div>
                    <p>Connaître les CGA et leur importance au grand public ivoirien ;
                        Créer un lien relationnel direct entre les CGA de Côte d'Ivoire, les PME/PMI, les Jeunes Entrepreneurs, les Jeunes en quête d'emploi, et toute personne désireuse de se former ou s'informer sur l'entreprenariat ;
                        Inciter le secteur informel à se structurer pour bénéficier des avantages offerts par la DGI à travers les CGA ;
                        Former la population ivoirienne, en particulier la jeunesse, sur les clés du succès des jeunes entrepreneurs, notamment par des retours d'expériences ; Sensibiliser la jeunesse ivoirienne à la pratique fiscale ;
                        Informer la jeunesse sur l'importance de parler l'anglais ;
                        Offrir des opportunités concrètes d'emplois aux jeunes à travers les entreprises partenaires.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->


    <!-- Feature Start -->
    <div class="container-fluid bg-image" style="margin: 90px 0;">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 my-5 pt-5 pb-lg-5">
                    <div class="section-title position-relative mb-4">
                        <h1 class="display-4">OBJECTIFS   CGA</h1>
                    </div>
                    <p class="mb-4 pb-2">Connaître les CGA et leur importance au grand public ivoirien ;
                        Créer un lien relationnel direct entre les CGA de Côte d'Ivoire, les PME/PMI, les Jeunes Entrepreneurs, les Jeunes en quête d'emploi, et toute personne désireuse de se former ou s'informer sur l'entreprenariat ;
                        Inciter le secteur informel à se structurer pour bénéficier des avantages offerts par la DGI à travers les CGA ;
                        Former la population ivoirienne, en particulier la jeunesse, sur les clés du succès des jeunes entrepreneurs, notamment par des retours d'expériences ; Sensibiliser la jeunesse ivoirienne à la pratique fiscale ;
                        Informer la jeunesse sur l'importance de parler l'anglais ;
                        Offrir des opportunités concrètes d'emplois aux jeunes à travers les entreprises partenaires.
                        </p>
                    <div class="d-flex mb-3">
                        <div class="btn-icon bg-primary mr-4">
                            <i class="fa fa-2x fa-graduation-cap text-white"></i>
                        </div>
                        <div class="mt-n1">
                            <h4> PANEL 1</h4>
                            <p>Il sera en relation avec l'analyse des données, l'intelligence artificielle, et la comptabilité des entreprises. Ces notions en lien avec la Finance sont d'actualité, et utiles à comprendre, d'où la nécessité de les retranscrire de manière accessible au grand public.</p>
                        </div>
                    </div>
                    <div class="d-flex mb-3">
                        <div class="btn-icon bg-secondary mr-4">
                            <i class="fa fa-2x fa-certificate text-white"></i>
                        </div>
                        <div class="mt-n1">
                            <h4> PANEL 2</h4>
                            <p>Il va concerner la fiscalité de création d'entreprise. Ces notions seront expliquées dans des termes clairs et concis afin de les rendre accessibles au grand public .</p>
                        </div>
                    </div>
                    <div class="d-flex">
                        <div class="btn-icon bg-warning mr-4">
                            <i class="fa fa-2x fa-book-reader text-white"></i>
                        </div>
                        <div class="mt-n1">
                            <h4> PANEL 3</h4>
                            <p class="m-0">Il s'agit d'expliquer à la jeunesse ivoirienne l'intérêt et l'importance de la pratique régulière de l'anglais professionnel international..</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5" style="min-height: 500px;">
                    <div class="position-relative h-50">
                        <img class="position-absolute w-100 h-100" src="img/feature.PNG" style="object-fit: cover;">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Feature Start -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Tech\all_vc_redist_x86_x64\Nouveau dossier\SGA\resources\views/Pages/about.blade.php ENDPATH**/ ?>